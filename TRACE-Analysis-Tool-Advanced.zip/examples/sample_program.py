from src.tracer import trace_function
import time

@trace_function
def task1():
    time.sleep(1)
    print("Task 1 complete")

@trace_function
def task2():
    time.sleep(2)
    print("Task 2 complete")

if __name__ == "__main__":
    task1()
    task2()
