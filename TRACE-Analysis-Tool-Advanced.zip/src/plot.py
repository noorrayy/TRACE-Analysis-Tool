import matplotlib.pyplot as plt

def plot_summary(summary):
    summary['Time'].plot(kind='bar', color='blue')
    plt.title("Function Execution Time")
    plt.xlabel("Function")
    plt.ylabel("Time (sec)")
    plt.savefig("results/execution_summary.png")
    plt.show()
