import pandas as pd

def read_trace(file_path):
    df = pd.read_csv(file_path, names=['Function','Time'])
    return df

def summarize_trace(df):
    summary = df.groupby('Function').sum()
    return summary
