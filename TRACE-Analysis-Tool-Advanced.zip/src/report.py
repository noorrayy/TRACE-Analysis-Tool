import pandas as pd

def save_report(df, summary):
    with pd.ExcelWriter("results/execution_report.xlsx") as writer:
        df.to_excel(writer, sheet_name="TraceLog", index=False)
        summary.to_excel(writer, sheet_name="Summary")
