# Helper functions (optional)
