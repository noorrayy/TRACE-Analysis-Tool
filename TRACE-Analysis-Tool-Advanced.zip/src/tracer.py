import time

def trace_function(func):
    """Decorator to trace function execution"""
    def wrapper(*args, **kwargs):
        start = time.time()
        print(f"[TRACE] Starting {func.__name__}")
        result = func(*args, **kwargs)
        end = time.time()
        print(f"[TRACE] Finished {func.__name__} in {end - start:.4f} sec")
        with open("results/trace_log.txt", "a") as f:
            f.write(f"{func.__name__},{end-start:.4f}\n")
        return result
    return wrapper
